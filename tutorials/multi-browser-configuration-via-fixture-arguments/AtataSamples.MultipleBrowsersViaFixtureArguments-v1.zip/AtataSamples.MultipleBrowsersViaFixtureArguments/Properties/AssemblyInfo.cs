﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Yevgeniy Shunevych")]
[assembly: AssemblyProduct("Atata Framework Samples")]
[assembly: AssemblyCopyright("Copyright © Yevgeniy Shunevych 2017")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

[assembly: AssemblyTitle("AtataSamples.MultipleBrowsersViaFixtureArguments")]
[assembly: Guid("67dbc114-6253-4210-8799-318e3099012b")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]