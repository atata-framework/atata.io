﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Yevgeniy Shunevych")]
[assembly: AssemblyProduct("Atata Framework Samples")]
[assembly: AssemblyCopyright("© Yevgeniy Shunevych 2017")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

[assembly: AssemblyTitle("AtataSamples.ValidationMessagesVerification")]
[assembly: Guid("62a7531b-bb9b-4dac-a874-5945d89e8d60")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]